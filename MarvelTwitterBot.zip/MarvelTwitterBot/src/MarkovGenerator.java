import java.util.ArrayList;
import java.util.Random;

public class MarkovGenerator<T> extends ProbabilityGenerator {
	ArrayList<ArrayList<Integer>> transitionTable = new ArrayList<ArrayList<Integer>>();
	ArrayList<ArrayList<Float>> normalize = new ArrayList<ArrayList<Float>>();

	public void train(ArrayList input) {
		int tokenIndex = 0; 
		int lastIndex = -1; 
		//System.out.println("Input =" +input);
		
		for (int i=0; i<input.size(); i++) { 
			tokenIndex = uniqueArray.indexOf(input.get(i));  

			if(tokenIndex == -1) {	
				tokenIndex = uniqueArray.size(); 
				ArrayList<Integer> row  = new ArrayList<Integer>(tokenIndex); 
				transitionTable.add(row);
				//System.out.println("Transition Table = " + transitionTable);
				
				for(int j= 0; j<uniqueArray.size(); j++) {
					row.add(0);	
				}
				//System.out.println("Row = " + transitionTable);

				for(int k=0; k< transitionTable.size(); k++) {
					transitionTable.get(k).add(0);
				}
				//System.out.println("Row = " + transitionTable);
				
				uniqueArray.add((T) input.get(i));
				//System.out.println("Unique  " + uniqueArray);
				}
	
			if(lastIndex > -1) {
				float access;
				ArrayList<Integer> row2 = transitionTable.get(lastIndex);
				access = row2.get(tokenIndex);	
				row2.set(tokenIndex, (int) (access + 1));
				}
			
			lastIndex = tokenIndex;
		}
	} 

	//prints out transition table
	public void printTable() {
		System.out.println("Counts Transition Table");
		System.out.println("Alphabet Array = " + uniqueArray);
		System.out.println("Transition Table");
		for(int i=0; i< transitionTable.size(); i++) {
			System.out.println(transitionTable.get(i));
		}
	}

	//prints out probabilities of the transition table
	public void probDist() {
		int size = transitionTable.size();
		ArrayList<Float> row = new ArrayList<Float>(size);
		for(int i=0; i< transitionTable.size(); i++) {	
			row = probabilityDistribution(transitionTable.get(i));
			normalize.add(row);
		}
		System.out.println("Probability Table ");
		for(int i=0; i<normalize.size(); i++) {
			System.out.println(normalize.get(i));
		}
	}
	 
	//creates a randomToken to generate from 
	public T randomToken(ArrayList<T> song) {
		int max = song.size();
		Random random = new Random();
		int randomNumber = random.nextInt(max); 
		T token  =song.get(randomNumber);
		return token;
	}
	
	//generates one token from train
	public T generate( T initToken) {
		int newIndex = uniqueArray.indexOf(initToken);
		//System.out.println("Index of character = " + newIndex);
		ArrayList<Integer> aRow = transitionTable.get(newIndex);
		//System.out.println("Indexed Row = " + aRow);
		T gen = (T) generate(aRow);
		//System.out.println((T) generate(aRow));
		return  gen;
		//System.out.println("Generated Item = "+ generate(aRow));
	}
	 
	//generates a list of tokens from train
	public ArrayList<T> generateMult( T initToken, int number) {
		ArrayList<T> genArray = new ArrayList();
		for(int i =0; i < number; i++) {
			T newToken  = generate(initToken);
			initToken = newToken; 
			genArray.add(newToken);
		}
	//	System.out.println("New Song =  " + genArray);
		return genArray; 
	}
	
}
