/*
 * c2019 Courtney Brown 
 * 
 * Class: HelloWorldStub
 * Description: This is a stub for a generic processing program
 * 
 */

import processing.core.*; //I've imported the processing library

//note that if you paste this code in you must change the name of this main class to the name of YOUR 
//main class so that the file name and the class name match
public class HelloWorldMain extends PApplet { //also NOTE that I have inherited from the Processing main class.



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PApplet.main("HelloWorldMain"); //I've told my parent class (the Processing project/application) that the
		//name of THIS class is "HelloWorldMain". Note that this MUST be the name 
		//of your main class.

	}

	public void settings() {

	}

	public void setup() {

	}

	public void draw() {

	}

	public void keyPressed() {

	}
}
