import java.util.ArrayList;
import java.util.Random;

public class MarkovOrderN<T> extends MarkovGenerator{
	ArrayList<T> input = new ArrayList<T>();
	ArrayList<T> alphabet = new ArrayList<T>();
	ArrayList<ArrayList<Integer>> transitionTable = new ArrayList<ArrayList<Integer>>(); 
	ArrayList<ArrayList<Float>> probability2 = new ArrayList<ArrayList<Float>>();   
	ArrayList<T> uniqueAlphabetSequence  = new ArrayList<T>(); 
	int rowIndex;
	int tokenIndex;
	
public void train(ArrayList input, int orderN) {
	
	for(int i = orderN-1; i< (input.size()-1) ; i++) 
	{
		int size= i - (orderN-1);
		ArrayList<T> curSequence = new ArrayList<T>(input.subList(size, i+1));
		rowIndex = uniqueAlphabetSequence.indexOf(curSequence);
		if (rowIndex == -1)
		{
			rowIndex = uniqueAlphabetSequence.size();
			uniqueAlphabetSequence.add((T) curSequence);
			
			ArrayList<Integer> row  = new ArrayList<Integer>(); 
			for(int j= 0; j < uniqueAlphabetSequence.size(); j++) {
				row.add(0);	
		}
			transitionTable.add(row);
		}
		
		if( (i+1) < input.size()) 
		{
			tokenIndex = alphabet.indexOf(input.get(i+1)); 
			if(tokenIndex == -1) {
				tokenIndex = alphabet.size();
				alphabet.add((T) input.get(i+1));
				for(int k =0; k<transitionTable.size(); k++) {
					transitionTable.get(k).add(0);
				} 	
			}
		}
		ArrayList<Integer> countRow = transitionTable.get(rowIndex);
		int setter;
		setter = countRow.get(tokenIndex);
		countRow.set(tokenIndex, (setter +1));
	}
}
	
	public void orderProb(){
		for (int i =0; i< transitionTable.size(); i++) {
			ArrayList<Integer> row = transitionTable.get(i);
			float sum =0;
			for(int j=0; j< row.size(); j++) {
				sum = sum +row.get(j);
			}
			ArrayList<Float> tempProb = new ArrayList<Float>();
			for(int k=0; k<row.size(); k++) {
				if(sum ==0) {
					tempProb.add(0.0f);
				} 
				else {
					float set = row.get(k)/sum;
					tempProb.add(set);
				}
			}	
			probability2.add(tempProb);
		}
	}

	public void print() {
		System.out.println("--Counts--");
		System.out.println("Alphabet = " + alphabet);
		for(int i=0; i< uniqueAlphabetSequence.size(); i++) {
			System.out.println(uniqueAlphabetSequence.get(i) + " : " + transitionTable.get(i));
		}
		System.out.println("--Probabilities--");
		System.out.println("Alphabet = " + alphabet);
		for(int j=0; j< uniqueAlphabetSequence.size(); j++) {
			System.out.println(uniqueAlphabetSequence.get(j) + " : " + probability2.get(j));
		}
	}
	
	//pass in an initial sequence the size of Order N
	public ArrayList<T> randomSeq(ArrayList<T> input, int orderN) {
		ArrayList<T> initSeq = new ArrayList<T>();
		int max = input.size();
		Random random = new Random();
		int randomNumber = random.nextInt(max); 
		T initial  = input.get(randomNumber);
		initSeq.add(initial);
		int initIndex;
		initIndex = input.indexOf(initial);
		for(int i=1; i < orderN; i++) {
			initSeq.add(input.get(initIndex+i));
		}
		System.out.println("Initial  sequence=" +  initSeq);
		return initSeq;
	}
	
	public T generate(ArrayList initSeq) {
		System.out.println("Alphabet seq" + uniqueAlphabetSequence);
		int curSeqIndex = uniqueAlphabetSequence.indexOf(initSeq);
		T token;
		System.out.println("CurSeqIndex = " + curSeqIndex);
		if(curSeqIndex == -1) {
			System.out.println("Init Seq of 0 =" + initSeq.get(0));
			token = (T) super.generate(initSeq.get(0));
		}
		else {
			ArrayList<Integer> aRow = transitionTable.get(curSeqIndex);
			token = (T) super.generate(aRow);
		}
		return token;
	}
	
	public ArrayList<T> generateMult(ArrayList initSeq, int numTokensToGen) {
		ArrayList<T> outputMelody = new  ArrayList<T>(numTokensToGen);
		for( int i =1; i<numTokensToGen; i++) {
			T newToken = generate(initSeq);
			System.out.println("New Token = "+ newToken);
			System.out.println("initSeq  untouched =" + initSeq.get(0));
			initSeq.remove(0);
			System.out.println("Init Seq removed =" + initSeq.get(0));
			initSeq.add(newToken);
			System.out.println("Init Seq Add =" + initSeq.get(0));
			outputMelody.add(newToken);
			System.out.println("Out Put Melody =" + outputMelody);
			initSeq.remove(0);
			System.out.println("Init Seq  Final =" + initSeq.get(0));
			
		}
		
		return null;	
	}
	
	
	
	
	
}
