import java.util.ArrayList;

public class ProbabilityGenerator<T> {
	ArrayList<T> uniqueArray = new ArrayList<T>();
	ArrayList<Integer> countArray = new ArrayList<Integer>(); 
	ArrayList<Float> normalize = new ArrayList<Float>();

	public void train(ArrayList<T> input) {

		for(int i =0; i< input.size(); i++) 
		{
			int ans = uniqueArray.indexOf(input.get(i));
			if (ans  == -1)
			{
				uniqueArray.add((T) input.get(i));
				countArray.add(1);
			}
			else 
			{
				countArray.set(ans, countArray.get(ans)+1);
			}
		}	
	} 

	public T generate(ArrayList<Integer> counts) {
		
		ArrayList<Float> normalize = new ArrayList<Float>();
		int sum =0;
	
		for(int i=0; i < counts.size(); i++) {
			sum = (int) (counts.get(i) +  sum);
		}
		
		for (int i =0; i <counts.size(); i++) {
			normalize.add((float) counts.get(i)/sum);
			//System.out.println("Token " + uniqueArray.get(i) + " Probability: " +normalize.get(i));
		}

		//generate random melody
		T gen = null;
		int index =0;
		float total  = 0; 
		float rIndex = (float)Math.random();  
		boolean found = false;
		while (!found && index<counts.size()-1) {
			total+= normalize.get(index);
			found = rIndex <= total;
			index++;
			//System.out.println("Index =" +index);
		}
		if(found == true) {
			gen = (uniqueArray.get(index-1));
		} 
		else {
			gen = (uniqueArray.get(index));
		}
		//System.out.println("rIndex" + rIndex);
		//System.out.println(gen);
		
		return gen; 
	}

	public ArrayList<T> generateMult(int number) {
		ArrayList<Float> normalize = new ArrayList<Float>();
		int sum =0;
		for(int i=0; i <countArray.size(); i++) {
			sum = countArray.get(i) +  sum;
		}
		
		for (int i =0; i <countArray.size(); i++) {
			normalize.add((float) countArray.get(i)/sum);
			//System.out.println("Token " + uniqueArray.get(i) + " Probability: " +normalize.get(i));
		}

		//generate random melody
		ArrayList<T> gen = new ArrayList<T>();
		//for loop checks the random number and returns a note based
		//on the normalize array
		for (int j =0; j<number; j ++) {
			int index =0;
			boolean found = false;
			float total  = 0;
			float rIndex = (float)Math.random();
			while (!found && index<countArray.size()-1) 
			{
				total += normalize.get(index);
				found = rIndex <=total;
				index++;

			}
			if (found ==true) {
				gen.add(uniqueArray.get(index-1));
			}
			else {
				gen.add(uniqueArray.get(index));
			}

		}
		//System.out.println(gen);
		return gen; 
	}

	public ArrayList<Float> probabilityDistribution(ArrayList<Integer> counts) {
		ArrayList<Float> normalize = new ArrayList<Float>();
		float sum =0;
		
		//this for loop counts the total
		for(int i=0; i <  counts.size(); i++) {
			sum = counts.get(i) +  sum;
		}
		
		for (int i =0; i <counts.size(); i++) {
			if(sum ==0) {
				normalize.add(0.0f);
			}
			else {
				normalize.add((float) counts.get(i)/sum);
			}
		}
		return normalize;
	}

	public void melodyGenerator(ArrayList<T> genList) {
		System.out.println(genList);
	}

}
